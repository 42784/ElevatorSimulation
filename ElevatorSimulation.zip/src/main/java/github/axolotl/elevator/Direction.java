package github.axolotl.elevator;

/**
 * @author AxolotlXM
 * @version 1.0
 * @since 2025/4/12 21:28
 */
public enum Direction {
    UP, DOWN, IDLE//空闲
    , WAIT//等待乘客等耗时操作
}