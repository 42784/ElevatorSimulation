package github.axolotl;

import github.axolotl.elevator.Building;
import github.axolotl.algorithm.Algorithm_FCFS;
import github.axolotl.passenger.PassengerGenerator;
import github.axolotl.passenger.rule.LimitedFloorRule;
import github.axolotl.passenger.rule.RandomIntervalRule;

/**
 * @author AxolotlXM
 * @version 1.0
 * @since 2025/4/12 20:42
 */
public class ElevatorSimulation {
    public static void main(String[] args) {



    }
}